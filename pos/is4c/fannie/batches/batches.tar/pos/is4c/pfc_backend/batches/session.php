<?php
session_start();
header("Cache-control; private");
echo "session started";
?>
