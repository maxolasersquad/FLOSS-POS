<?php

$db = mssql_connect('129.103.2.10','sa');
mssql_select_db('WedgePOS',$db);

//$query = "exec updateProd";
//$result = mssql_query($query);


?>