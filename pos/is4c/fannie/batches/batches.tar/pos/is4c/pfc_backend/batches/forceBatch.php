<?
include('../funct1Mem.php');

$batchID = $_GET['batchID'];

$forceQ="UPDATE products 
SET start_date = b.startdate, 
    end_date=b.enddate,
    special_price=l.salePrice,
    discounttype=b.discounttype
FROM products as p, 
     IS4CSERV.wedgePOS.dbo.batches as b, 
     IS4CSERV.wedgePOS.dbo.batchlist as l 
WHERE datediff(dd,getdate(),b.startDate) < 1
      AND datediff(dd,getdate(),b.endDate) > 0
AND l.upc = p.upc
and b.batchID = l.batchID
and b.batchID = $batchID";

$forceR = mssql_query($forceQ);

$batchUpQ = "EXEC batchUpdate";
$batchUpR = mssql_query($batchUpQ);

echo "Batch $batchID has been forced";


?>

