<?

$num = 0;

if($num > 1){

echo "<SCRIPT>
       window.alert('This is a test')
      </SCRIPT>";
}else{
   echo '$num <= 1';
}


?>
