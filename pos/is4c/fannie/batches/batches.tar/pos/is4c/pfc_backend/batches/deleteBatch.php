<?php

$db = mssql_connect('129.103.2.10','sa');
mssql_select_db('WedgePOS',$db);

if (isset($_POST['yes'])){
  $batchID = $_POST['batchID'];
  $delBatchQ = "delete from batches where batchID = $batchID";
  echo $delBatchQ."<br />";
  $delBatchR = mssql_query($delBatchQ);
  $delItemsQ = "delete from batchlist where batchID = $batchID";
  echo $delItemsQ."<br />";
  $delBatchR = mssql_query($delItemsQ);
  $updateQ = "exec batchUpdate";
  $updateR = mssql_query($updateQ);
  echo "Batch #$batchID deleted<p />";
  echo "Return to <a href=index.php>list of batches</a>";
}
else {
  $batchID = $_GET['batchID'];
  $fetchQ = "select batchName from batches where batchID = $batchID";
  $fetchR = mssql_query($fetchQ);
  $fetchRow = mssql_fetch_row($fetchR);
  $name = $fetchRow[0];

  echo "Are you sure you want to delete batch #$batchID ($name)<br />";
  echo "<table cellspacing=4 cellpadding=4><tr><td>";
  echo "<form action=deleteBatch.php method=post>";
  echo "<input type=hidden name=batchID value=$batchID>";
  echo "<input type=submit name=yes value=Yes>";
  echo "</form>";
  echo "</td><td>";
  echo "<form action=index.php method=post>";
  echo "<input type=submit name=no value=No>";
  echo "</form>";
  echo "</td></tr></table>";
}

?>